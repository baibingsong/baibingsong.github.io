package org.example;


import java.io.IOException;
import java.io.StringWriter;
import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class MyTag4 extends SimpleTagSupport {
	String foreColor;
	String text;
	String size;
	String color;
	Date date = new Date();
	public void doTag() throws JspException, IOException {
		JspWriter out = getJspContext().getOut();

		if (foreColor != null) {
			out.write(String.format("<span style='color:%s'>%s</span>", foreColor, text));
		}
		else
			{ //out.write(String.format("<span>%s</span>", text));
			}
		if(color !=null)
		out.println(String.format("<span style='color:%s' size='size:%s'>%s</span>", color, size, date));

		}


		// Setters
		public void setForeColor (String foreColor){

			this.foreColor = foreColor;
		}

		public void setText (String text){
			this.text = text;
		}
		public void setColor (String color){
			this.color = color;
		}
		public void setSize (String size){
			this.size = size;
		}

		public void setDate (Date date){
			this.date = date;
		}
	}
